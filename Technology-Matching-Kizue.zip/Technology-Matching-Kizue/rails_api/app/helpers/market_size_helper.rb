module MarketSizeHelper
end
